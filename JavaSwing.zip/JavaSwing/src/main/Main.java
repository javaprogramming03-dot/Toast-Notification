
package main;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.SwingUtilities;
import test.Test;

public class Main {
    
    public static void main(String args[]){
        FlatLightLaf.setup();
        SwingUtilities.invokeLater(()-> new Test().setVisible(true));
    }
    
}
