package utils;

// import ng Toast component mo
import component.Toast;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ToastManager {

    //ist ng active toasts (stacked vertically)
    private static final List<Toast> toasts = new ArrayList<>();

    //spacing between toasts
    private static final int GAP = 10;

    // top margin (distance from top screen)
    private static final int TOP_MARGIN = 20;

    // store last known Y positions (for smooth layout)
    private static final java.util.Map<Toast, Integer> originalYMap = new java.util.HashMap<>();

    //  SINGLE layout engine (prevents shaking / multiple timers conflict)
    private static Timer layoutTimer;

    // =========================
    // MAIN METHOD (SHOW TOAST)
    // =========================
    public static void showToast(JFrame frame, String message, Option type, boolean gradient) {

        //  get layered pane (important for floating UI)
        JLayeredPane layeredPane = frame.getLayeredPane();

        //  create toast
        Toast toast = new Toast(message, type);

        //  apply gradient setting
        toast.setUseGradient(gradient);

        // get preferred size
        Dimension size = toast.getPreferredSize();

        //  center horizontally
        int x = (frame.getWidth() - size.width) / 2;

        //start above screen (for animation)
        toast.setBounds(x, -80, size.width, size.height);

        //invisible at start
        toast.setAlpha(0f);

        //  add to layered pane (POPUP_LAYER = above everything)
        layeredPane.add(toast, JLayeredPane.POPUP_LAYER);

        // add to list (top priority = index 0)
        toasts.add(0, toast);

        // animate entrance
        animateIn(toast);

        //auto remove after delay
        scheduleRemove(frame, toast);

        // 🔹 start layout engine (only once)
        startLayoutEngine();
    }

    //  ANIMATE IN (SLIDE + FADE)

    private static void animateIn(Toast toast) {

        // 🔹 60 FPS timer (~16ms)
        Timer timer = new Timer(16, null);

        final int startY = -80;         // starting position (hidden)
        final int targetY = TOP_MARGIN; // final position

        final float[] p = {0f}; // progress (0 → 1)

        timer.addActionListener(e -> {

            p[0] += 0.08f; // speed

            if (p[0] >= 1f) {
                p[0] = 1f;
                timer.stop();
            }

            float ease = easeOut(p[0]); // smooth easing

            //interpolate Y position
            int y = (int) (startY + (targetY - startY) * ease);

            toast.setLocation(toast.getX(), y);

            //fade in
            toast.setAlpha(ease);
        });

        timer.start();
    }

    // LAYOUT ENGINE (STACK TOASTS)

    private static void startLayoutEngine() {

        // prevent multiple timers (important fix)
        if (layoutTimer != null && layoutTimer.isRunning()) return;

        layoutTimer = new Timer(16, null);

        layoutTimer.addActionListener(e -> {

            int y = TOP_MARGIN; // starting Y
            boolean moving = false;

            for (Toast t : toasts) {

                int targetY = y;         // where it should go
                int currentY = t.getY(); // current position

                int diff = targetY - currentY;

                // smooth movement (lerp)
                int newY = currentY + (int)(diff * 0.22);

                if (Math.abs(diff) > 1) {
                    moving = true;
                }

                t.setLocation(t.getX(), newY);

                // store position
                originalYMap.put(t, t.getY());

                // next toast position
                y += t.getPreferredSize().height + GAP;
            }

            // stop engine if no more movement and no toasts
            if (!moving && toasts.size() == 0) {
                layoutTimer.stop();
                layoutTimer = null;
            }
        });

        layoutTimer.start();
    }

    // AUTO REMOVE AFTER 3s

    private static void scheduleRemove(JFrame frame, Toast toast) {

        // delay timer (3000ms)
        new Timer(3000, e -> removeToast(frame, toast)).start();
    }

    //  START REMOVE ANIMATION

    private static void removeToast(JFrame frame, Toast toast) {

        int index = toasts.indexOf(toast);

        if (index == -1) return;

        Timer timer = new Timer(16, null);

        final float[] p = {0f};

        timer.addActionListener(e -> {

            p[0] += 0.05f;

            if (p[0] >= 1f) {
                p[0] = 1f;
                timer.stop();

                // 🔹 start fade-out phase
                startFadeOut(frame, toast, index);
                return;
            }

            float ease = easeInOut(p[0]);

            int y = toast.getY();

            //slight upward movement habang nawawala
            toast.setLocation(toast.getX(), y - (int)(ease * 7));

            // fade out
            toast.setAlpha(1f - ease);
        });

        timer.start();
    }

    // easing function (smooth in/out)
    private static float easeInOut(float t) {
        return t < 0.5f
                ? 4 * t * t * t
                : 1 - (float)Math.pow(-2 * t + 2, 3) / 2;
    }

    //  FINAL FADE OUT + REMOVE

    private static void startFadeOut(JFrame frame, Toast toast, int index) {

        Timer fade = new Timer(16, null);

        fade.addActionListener(e -> {

            // FIXED: gradual fade (NOT -1f ❌)
            float alpha = toast.getAlpha() - 0.08f;

            if (alpha <= 0f) {

                fade.stop();

                //  remove from UI
                frame.getLayeredPane().remove(toast);
                frame.repaint();

                // remove from list
                toasts.remove(toast);

                // adjust remaining toasts
                shiftAbove(index);

            } else {
                toast.setAlpha(alpha);
            }
        });

        fade.start();
    }

    // SHIFT TOASTS UP AFTER REMOVE

    private static void shiftAbove(int removedIndex) {

        Timer timer = new Timer(16, null);

        timer.addActionListener(e -> {

            boolean moving = false;

            int y = TOP_MARGIN;

            for (int i = 0; i < toasts.size(); i++) {

                Toast t = toasts.get(i);

                int targetY = y;
                int currentY = t.getY();

                int diff = targetY - currentY;

                // smooth movement
                int newY = currentY + (int)(diff * 0.25);

                if (Math.abs(diff) > 1) {
                    moving = true;
                }

                t.setLocation(t.getX(), newY);

                y += t.getHeight() + GAP;
            }

            if (!moving) {
                timer.stop();
            }
        });

        timer.start();
    }

    //  ease-out (used for smooth entry)
    private static float easeOut(float t) {
        return (float)(1 - Math.pow(1 - t, 3));
    }
}