package utils;

import com.formdev.flatlaf.extras.FlatSVGIcon;

public class IconUtil {

    public static FlatSVGIcon load(String name, int size) {
        return new FlatSVGIcon("svg/" + name + ".svg", size, size);
    }
}