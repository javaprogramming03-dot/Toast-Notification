package utils;

import java.awt.*;

public class ToastShadow {

    // SHADOW PRESETS (FlatLaf-style elevation)


    public enum Style {
        SOFT,      // minimal / glass UI
        MEDIUM,    // default (FlatLaf-like)
        STRONG     // deep floating UI
    }

    // MAIN PAINT METHOD

    public static void paint(Graphics2D g2, int w, int h, int radius, boolean darkMode) {
        paint(g2, w, h, radius, darkMode, Style.MEDIUM);
    }

    public static void paint(Graphics2D g2, int w, int h, int radius, boolean darkMode, Style style) {

        // CONFIG BASED ON STYLE

        int layers;
        int maxSpread;
        float baseAlpha;

        switch (style) {

            case SOFT -> {
                layers = 5;
                maxSpread = 6;
                baseAlpha = darkMode ? 0.04f : 0.06f;
            }

            case STRONG -> {
                layers = 10;
                maxSpread = 14;
                baseAlpha = darkMode ? 0.18f : 0.12f;
            }

            default -> { // MEDIUM (FlatLaf default feel)
                layers = 6;
                maxSpread = 8;
                baseAlpha = darkMode ? 0.08f : 0.10f;
            }
        }

        // MAIN SHADOW RENDER

        for (int i = 0; i < layers; i++) {

            float t = (float) i / (float) layers;

            // FlatLaf-like easing curve
            float fade = (1f - t);
            fade = fade * fade;

            int alpha = (int) (255 * baseAlpha * fade);
            if (alpha < 1) continue;

            int spread = (int) (maxSpread * t);

            Color shadow = darkMode
                    ? new Color(0, 0, 0, alpha)
                    : new Color(0, 0, 0, (int) (alpha * 0.75));

            g2.setColor(shadow);

            int yOffset = 1;

            g2.fillRoundRect(
                    6 + spread,
                    h - 10 + spread + yOffset,
                    w - (12 + spread * 2),
                    2 + spread,
                    radius + 10,
                    radius + 10
            );
        }

        // CORE FLATLAF DEPTH (center glow)

        g2.setColor(new Color(0, 0, 0, darkMode ? 18 : 10));

        g2.fillRoundRect(
                8,
                h - 8,
                w - 16,
                6,
                radius + 6,
                radius + 6
        );
    }
    
}
/* 
way of use this shadow
default -  ToastShadow.paint(g2, w, h, radius, isDarkMode());
soft - ToastShadow.paint(g2, w, h, radius, isDarkMode(), ToastShadow.Style.SOFT);
medium - ToastShadow.paint(g2, w, h, radius, isDarkMode(), ToastShadow.Style.MEDIUM);
strong - ToastShadow.paint(g2, w, h, radius, isDarkMode(), ToastShadow.Style.STRONG);
*/