package utils;

import javax.swing.JFrame;

public class SampleToast {

    // =========================
    // 🎯 SUCCESS SAMPLE
    // =========================
    public static void showSuccess(JFrame frame, boolean gradient) {
        ToastManager.showToast(
                frame,
                "Congratulations you passed the Test Examination!",
                Option.SUCCESS,
                gradient
        );
    }

    // =========================
    // ❌ ERROR SAMPLE
    // =========================
    public static void showError(JFrame frame, boolean gradient) {
        ToastManager.showToast(
                frame,
                "Something went wrong while processing your request!",
                Option.ERROR,
                gradient
        );
    }

    // =========================
    // ⚠️ WARNING SAMPLE
    // =========================
    public static void showWarning(JFrame frame, boolean gradient) {
        ToastManager.showToast(
                frame,
                "Warning: Please check your input before continuing!",
                Option.WARNING,
                gradient
        );
    }

    // =========================
    // ℹ️ INFO SAMPLE
    // =========================
    public static void showInfo(JFrame frame, boolean gradient) {
        ToastManager.showToast(
                frame,
                "Information loaded successfully!",
                Option.INFO,
                gradient
        );
    }

    // =========================
    // 🎯 CUSTOM MESSAGE SHORTCUT
    // =========================
    public static void show(JFrame frame, String message, Option type, boolean gradient) {
        ToastManager.showToast(frame, message, type, gradient);
    }
}