
package utils;


public enum Option {
    SUCCESS,
    ERROR,
    WARNING,
    INFO
}