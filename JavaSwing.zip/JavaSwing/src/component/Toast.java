
package component;

import com.formdev.flatlaf.extras.FlatSVGIcon;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import javax.swing.UIManager;
import utils.IconUtil;
import utils.Option;
import utils.ToastShadow;

public class Toast extends javax.swing.JPanel {

    
    // type of toast (SUCCESS, ERROR, etc.)
    private Option type;

    //transparency (used for animation fade in/out)
    private float alpha = 0f;

    //toggle if gradient is used
    private boolean useGradient = false;
    
    public Toast(String message, Option type) {
        
        initComponents();

        setOpaque(false); // important: allow custom painting

        this.type = type; // save type

        lbMessage.setText(message); // set message text

        applyOption(type); // apply icon + colors

        setupClose(); // setup close button

    }

    //convert HEX string to Color object
    private Color fromHex(String hex) {
        return Color.decode(hex);
    }
    // return accent color based on toast type
    private Color getAccent(Option type) {
        return switch (type) {
            case SUCCESS -> fromHex("#1EA97C"); // green
            case INFO -> fromHex("#3B82F6");    // blue
            case WARNING -> fromHex("#CC8925"); // orange
            case ERROR -> fromHex("#FF5757");   // red
        };
    }
    // set alpha (used for fade animation)
    public void setAlpha(float alpha) {
        this.alpha = alpha;
        repaint(); // redraw UI
    }

    public float getAlpha() {
        return alpha;
    }


    // APPLY STYLE BASED ON TYPE
    private void applyOption(Option type) {

        Color accent = getAccent(type); // get accent color

        FlatSVGIcon icon = null;

        // choose icon depending on type
        switch (type) {
            case SUCCESS -> icon = IconUtil.load("success", 24);
            case ERROR -> icon = IconUtil.load("error", 24);
            case WARNING -> icon = IconUtil.load("warning", 24);
            case INFO -> icon = IconUtil.load("info", 24);
        }

        if (icon != null) {

            if (useGradient) {
                Color base = getAccent(type);

                // fake gradient color effect for icon
                icon.setColorFilter(new FlatSVGIcon.ColorFilter(c -> {

                    int r = Math.min(255, base.getRed() + 40);
                    int g = Math.min(255, base.getGreen() + 40);
                    int b = Math.min(255, base.getBlue() + 40);

                    return new Color(r, g, b); // brighter version
                }));

            } else {
                // normal solid color
                icon.setColorFilter(new FlatSVGIcon.ColorFilter(c -> getAccent(type)));
            }

            lbIcon.setIcon(icon); // set icon to label
        }

        //CLOSE BUTTON ICON
        FlatSVGIcon closeIcon = IconUtil.load("close", 12);

        // gray color
        closeIcon.setColorFilter(new FlatSVGIcon.ColorFilter(c -> new Color(150,150,150)));

        lbClose.setIcon(closeIcon);

        // change cursor to hand (clickable)
        lbClose.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    // CLOSE BUTTON FUNCTIONALITY
    private void setupClose() {

        lbClose.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {

                Container parent = getParent(); // get parent container

                if (parent != null) {
                    parent.remove(Toast.this); // remove this toast
                    parent.repaint(); // refresh UI
                }
            }
        });
    }

    // enable / disable gradient mode
    public void setUseGradient(boolean useGradient) {

        this.useGradient = useGradient;

        applyOption(type); // refresh icon

        repaint(); // redraw UI
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbIcon = new javax.swing.JLabel();
        lbMessage = new javax.swing.JLabel();
        lbClose = new javax.swing.JLabel();

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(lbIcon, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbMessage, javax.swing.GroupLayout.DEFAULT_SIZE, 218, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbClose, javax.swing.GroupLayout.DEFAULT_SIZE, 19, Short.MAX_VALUE)
                .addGap(8, 8, 8))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbMessage, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                    .addComponent(lbIcon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbClose, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(8, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents
        
    

    //  detect if dark mode
    private boolean isDarkMode() {

        Color bg = UIManager.getColor("Panel.background");

        if (bg == null) return false;

        //  luminance formula (brightness detection)
        int lum = (int) (0.299 * bg.getRed()
                + 0.587 * bg.getGreen()
                + 0.114 * bg.getBlue());

        return lum < 128; // dark if below 128
    }


    //background color depending on theme
    private Color getToastBackground() {
        return isDarkMode()
                ? new Color(69, 55, 87) // dark mode
                : new Color(247, 251, 255); // light mode
    }

    // CUSTOM PAINTING (MAIN UI)
    @Override
    protected void paintComponent(Graphics g) {

        Graphics2D g2 = (Graphics2D) g.create(); // create copy

        // enable smooth rendering
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        // apply transparency (alpha)
        g2.setComposite(AlphaComposite.SrcOver.derive(alpha));

        int w = getWidth();
        int h = getHeight();

        int radius = 10; // rounded corner

        //  draw shadow
        ToastShadow.paint(g2, w, h, radius, isDarkMode(), ToastShadow.Style.SOFT);

        // main card shape
        Shape card = new RoundRectangle2D.Float(6, 6, w - 12, h - 12, radius, radius);

        if (useGradient) {

            Color base = getAccent(type);

            // gradient start color
            Color start = new Color(
                    (base.getRed() + 255) / 2,
                    (base.getGreen() + 255) / 2,
                    (base.getBlue() + 255) / 2,
                    160
            );

            // transparent end (fade out)
            Color end = new Color(255, 255, 255, 0);

            GradientPaint gp = new GradientPaint(
                    0, 0, start,
                    w, 0, end
            );

            g2.setPaint(gp);

        } else {
            // normal background
            g2.setColor(getToastBackground());
        }

        g2.fill(card); // draw background

        // ================= ACCENT BAR =================
        Shape oldClip = g2.getClip();

        RoundRectangle2D.Float cardShape =
                new RoundRectangle2D.Float(5,5, w - 14, h - 14, radius, radius);

        g2.setClip(cardShape); // prevent overflow

        Color accent = getAccent(type);

        int barWidth = 3;
        int offset = 2;

        if (useGradient) {

            Color brighter = accent.brighter();

            GradientPaint gp = new GradientPaint(
                    6, 0,
                    brighter,
                    6 + barWidth, 0,
                    accent
            );

            g2.setPaint(gp);

        } else {
            g2.setColor(accent);
        }

        //  draw left accent bar
        g2.fillRect(
                8 + offset,
                8 + offset,
                barWidth,
                h - 12 - (offset * 2)
        );

        g2.setClip(oldClip); // restore clip

        g2.dispose(); // cleanup
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lbClose;
    private javax.swing.JLabel lbIcon;
    private javax.swing.JLabel lbMessage;
    // End of variables declaration//GEN-END:variables
}
